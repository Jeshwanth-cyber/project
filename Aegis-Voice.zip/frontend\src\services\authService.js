import apiClient from './api';

export const authService = {
  async register(data) {
    const res = await apiClient.post('/api/auth/register', data);
    return res?.data || {};
  },

  async login(data) {
    const res = await apiClient.post('/api/auth/login', data);
    return res?.data || {};
  },

  async logout() {
    try {
      const res = await apiClient.post('/api/auth/logout');
      return res?.data || {};
    } catch {
      // Even if network or endpoint fails, local session is cleared
      return { success: true };
    }
  },
};

export default authService;
