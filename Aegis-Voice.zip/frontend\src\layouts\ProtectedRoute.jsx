import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Shield } from 'lucide-react';

export default function ProtectedRoute({ children }) {
  const { isAuthenticated, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 dark:bg-navy-950 text-slate-600 dark:text-slate-300">
        <div className="w-12 h-12 rounded-2xl bg-brand-blue flex items-center justify-center text-white mb-4 animate-bounce">
          <Shield className="w-6 h-6" />
        </div>
        <p className="text-sm font-medium">Securing session...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
}
