import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import authService from '../services/authService';
import profileService from '../services/profileService';
import toast from 'react-hot-toast';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('aegis_token'));
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem('aegis_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(true);

  // Sync token changes to localStorage
  const setAuthSession = useCallback((newToken, userData) => {
    if (newToken) {
      localStorage.setItem('aegis_token', newToken);
      setToken(newToken);
    }
    if (userData) {
      localStorage.setItem('aegis_user', JSON.stringify(userData));
      setUser(userData);
    }
  }, []);

  const clearAuthSession = useCallback(() => {
    localStorage.removeItem('aegis_token');
    localStorage.removeItem('aegis_user');
    setToken(null);
    setUser(null);
  }, []);

  // Fetch current user if token exists on boot
  useEffect(() => {
    let isMounted = true;

    async function loadUser() {
      if (!token) {
        setLoading(false);
        return;
      }

      try {
        const profileData = await profileService.getProfile();
        if (isMounted && profileData) {
          const updatedUser = profileData?.user || profileData;
          setUser(updatedUser);
          localStorage.setItem('aegis_user', JSON.stringify(updatedUser));
        }
      } catch (err) {
        // If 401, session is already cleared by interceptor
        if (err?.response?.status === 401) {
          clearAuthSession();
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadUser();

    // Listen for auth_expired custom event triggered by api.js on 401
    const handleAuthExpired = () => {
      clearAuthSession();
      toast.error('Session expired. Please log in again to continue safely.', { id: 'session-expired' });
    };

    window.addEventListener('aegis:auth_expired', handleAuthExpired);

    return () => {
      isMounted = false;
      window.removeEventListener('aegis:auth_expired', handleAuthExpired);
    };
  }, [token, clearAuthSession]);

  const login = async (email, password) => {
    const data = await authService.login({ email, password });
    const receivedToken = data?.token || data?.access_token || data?.jwt;
    const userData = data?.user || { email, name: data?.name || email.split('@')[0] };

    if (!receivedToken) {
      throw new Error('Authentication response did not contain a valid security token.');
    }

    setAuthSession(receivedToken, userData);
    return { token: receivedToken, user: userData };
  };

  const register = async (userData) => {
    const data = await authService.register(userData);
    const receivedToken = data?.token || data?.access_token || data?.jwt;
    const resolvedUser = data?.user || {
      name: userData.name,
      email: userData.email,
    };

    if (receivedToken) {
      setAuthSession(receivedToken, resolvedUser);
    }

    return { token: receivedToken, user: resolvedUser };
  };

  const logout = async () => {
    try {
      await authService.logout();
    } catch {
      // Ignore network errors on logout
    } finally {
      clearAuthSession();
      toast.success('You have been safely signed out.');
    }
  };

  const updateUser = (newUserData) => {
    setUser((prev) => {
      const merged = { ...prev, ...newUserData };
      localStorage.setItem('aegis_user', JSON.stringify(merged));
      return merged;
    });
  };

  return (
    <AuthContext.Provider
      value={{
        token,
        user,
        isAuthenticated: Boolean(token),
        loading,
        login,
        register,
        logout,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export default AuthContext;
