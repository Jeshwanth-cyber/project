import React, { useState } from 'react';
import Modal from './Modal';
import Button from './Button';
import evidenceService from '../services/evidenceService';
import toast from 'react-hot-toast';
import { ShieldCheck } from 'lucide-react';

export default function SaveEvidenceModal({
  isOpen,
  onClose,
  initialData = {},
  onSaved,
}) {
  const [title, setTitle] = useState(initialData.title || initialData.category || 'Incident Evidence');
  const [description, setDescription] = useState(
    initialData.explanation || initialData.description || ''
  );
  const [sourceUrl, setSourceUrl] = useState(initialData.source_url || initialData.url || '');
  const [loading, setLoading] = useState(false);

  // Sync initialData changes when opened
  React.useEffect(() => {
    if (isOpen) {
      setTitle(initialData.title || initialData.category || 'Digital Safety Incident Evidence');
      setDescription(initialData.explanation || initialData.description || '');
      setSourceUrl(initialData.source_url || initialData.url || '');
    }
  }, [isOpen, initialData]);

  const handleSave = async (e) => {
    e.preventDefault();
    if (!title.trim()) {
      toast.error('Please provide a title for this evidence record.');
      return;
    }

    setLoading(true);
    try {
      const payload = {
        title: title.trim(),
        description: description.trim(),
        source_url: sourceUrl.trim() || null,
        category: initialData.category || initialData.type || 'Media Manipulation',
        risk_level: initialData.risk_level || initialData.risk || 'Unrated',
        confidence: initialData.confidence || initialData.score || null,
        indicators: initialData.indicators || [],
        metadata: {
          saved_at: new Date().toISOString(),
          original_id: initialData.id || null,
          platform: initialData.platform || 'Direct Upload',
          timestamps: initialData.timestamps || [],
        },
      };

      const result = await evidenceService.createEvidence(payload);
      toast.success('Evidence record secured in your private vault.');
      if (onSaved) onSaved(result);
      onClose();
    } catch (err) {
      toast.error(err?.friendlyMessage || 'Failed to save evidence to vault.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Save to Evidence Vault"
      subtitle="Preserve structured forensic indicators and metadata under your custody."
    >
      <form onSubmit={handleSave} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
            Record Title *
          </label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full rounded-lg border border-slate-300 dark:border-navy-600 bg-white dark:bg-navy-900 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-blue"
            placeholder="e.g. Deepfake video circulated on Telegram"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
            Source URL / Reference (Optional)
          </label>
          <input
            type="url"
            value={sourceUrl}
            onChange={(e) => setSourceUrl(e.target.value)}
            className="w-full rounded-lg border border-slate-300 dark:border-navy-600 bg-white dark:bg-navy-900 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-blue"
            placeholder="https://..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
            Description / Context Notes
          </label>
          <textarea
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full rounded-lg border border-slate-300 dark:border-navy-600 bg-white dark:bg-navy-900 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-blue"
            placeholder="Notes regarding dates, circulating platforms, or harassment context..."
          />
        </div>

        <div className="p-3 bg-slate-50 dark:bg-navy-900 rounded-lg border border-slate-200 dark:border-navy-700 text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
          <span>
            Records are stored in your encrypted account and can be downloaded as a verified JSON packet anytime.
          </span>
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <Button type="button" variant="outline" size="sm" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button type="submit" variant="primary" size="sm" loading={loading} icon={ShieldCheck}>
            Save Record
          </Button>
        </div>
      </form>
    </Modal>
  );
}
