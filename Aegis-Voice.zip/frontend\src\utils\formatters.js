export function formatDate(dateString) {
  if (!dateString) return 'Unknown date';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(d);
  } catch {
    return dateString;
  }
}

export function formatFileSize(bytes) {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export function getRiskMeta(level) {
  const normalized = String(level || '').toLowerCase().trim();
  switch (normalized) {
    case 'critical':
    case 'danger':
    case 'severe':
    case 'high':
      return {
        label: 'High Risk',
        color: 'danger',
        bg: 'bg-red-50 dark:bg-red-950/40',
        text: 'text-red-700 dark:text-red-400',
        border: 'border-red-200 dark:border-red-800/60',
        dot: 'bg-red-500',
      };
    case 'medium':
    case 'moderate':
    case 'warning':
      return {
        label: 'Moderate Risk',
        color: 'warning',
        bg: 'bg-amber-50 dark:bg-amber-950/40',
        text: 'text-amber-700 dark:text-amber-400',
        border: 'border-amber-200 dark:border-amber-800/60',
        dot: 'bg-amber-500',
      };
    case 'low':
    case 'minimal':
      return {
        label: 'Low Risk',
        color: 'cyan',
        bg: 'bg-cyan-50 dark:bg-cyan-950/40',
        text: 'text-cyan-700 dark:text-cyan-400',
        border: 'border-cyan-200 dark:border-cyan-800/60',
        dot: 'bg-cyan-500',
      };
    case 'safe':
    case 'benign':
    case 'clear':
      return {
        label: 'Clean / Safe',
        color: 'safe',
        bg: 'bg-emerald-50 dark:bg-emerald-950/40',
        text: 'text-emerald-700 dark:text-emerald-400',
        border: 'border-emerald-200 dark:border-emerald-800/60',
        dot: 'bg-emerald-500',
      };
    default:
      return {
        label: level || 'Unrated',
        color: 'neutral',
        bg: 'bg-slate-100 dark:bg-slate-800/60',
        text: 'text-slate-700 dark:text-slate-300',
        border: 'border-slate-200 dark:border-slate-700',
        dot: 'bg-slate-400',
      };
  }
}

/**
 * Detect Indian script or Latin code-mixed script
 */
export function detectScript(text) {
  if (!text) return 'English';
  
  const devanagariRegex = /[\u0900-\u097F]/;
  const teluguRegex = /[\u0C00-\u0C7F]/;
  const tamilRegex = /[\u0B80-\u0BFF]/;
  const latinRegex = /[a-zA-Z]/;

  const hasDevanagari = devanagariRegex.test(text);
  const hasTelugu = teluguRegex.test(text);
  const hasTamil = tamilRegex.test(text);
  const hasLatin = latinRegex.test(text);

  if (hasDevanagari && hasLatin) return 'Hinglish (Code-mixed)';
  if (hasTamil && hasLatin) return 'Tanglish (Code-mixed)';
  if (hasTelugu && hasLatin) return 'Telugu-English (Code-mixed)';
  if (hasDevanagari) return 'Hindi (Devanagari)';
  if (hasTelugu) return 'Telugu (తెలుగు)';
  if (hasTamil) return 'Tamil (தமிழ்)';
  if (hasLatin) return 'English (Latin)';

  return 'Multilingual Text';
}

export function truncateText(text, length = 80) {
  if (!text) return '';
  if (text.length <= length) return text;
  return text.substring(0, length) + '...';
}
