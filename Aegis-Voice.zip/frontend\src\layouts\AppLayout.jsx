import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';
import MobileNav from './MobileNav';
import { Toaster } from 'react-hot-toast';

export default function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-navy-950 text-slate-800 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      <Toaster
        position="top-right"
        toastOptions={{
          className: 'text-xs sm:text-sm font-medium',
          duration: 4000,
          style: {
            borderRadius: '12px',
            background: 'var(--navy-surface, #0F172A)',
            color: '#F8FAFC',
            border: '1px solid rgba(148, 163, 184, 0.2)',
          },
        }}
      />

      {/* Desktop / Responsive Sidebar */}
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {/* Main Area Offset by Sidebar on Desktop */}
      <div className="flex-1 flex flex-col md:pl-64 transition-all duration-200">
        <Header
          isSidebarOpen={sidebarOpen}
          onToggleSidebar={() => setSidebarOpen((prev) => !prev)}
        />

        {/* Content Outlet */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto pb-20 md:pb-8">
          <Outlet />
        </main>

        {/* Bottom Bar for Mobile screens */}
        <MobileNav />
      </div>
    </div>
  );
}
