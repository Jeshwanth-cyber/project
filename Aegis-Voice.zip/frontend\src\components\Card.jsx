import React from 'react';

export default function Card({
  children,
  className = '',
  title,
  subtitle,
  action,
  headerBorder = true,
  padding = true,
  ...props
}) {
  return (
    <div
      className={`bg-white dark:bg-navy-800 rounded-xl border border-slate-200/80 dark:border-navy-700 shadow-sm transition-colors ${className}`}
      {...props}
    >
      {(title || subtitle || action) && (
        <div
          className={`flex items-start justify-between gap-4 p-5 sm:p-6 ${
            headerBorder ? 'border-b border-slate-100 dark:border-navy-700' : ''
          }`}
        >
          <div>
            {title && (
              <h3 className="text-base sm:text-lg font-semibold text-slate-900 dark:text-slate-100">
                {title}
              </h3>
            )}
            {subtitle && (
              <p className="mt-1 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                {subtitle}
              </p>
            )}
          </div>
          {action && <div className="shrink-0">{action}</div>}
        </div>
      )}
      <div className={padding ? 'p-5 sm:p-6' : ''}>{children}</div>
    </div>
  );
}
