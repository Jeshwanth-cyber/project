import React from 'react';
import { Scale, Info } from 'lucide-react';
import { JURISDICTION_DISCLAIMER } from '../utils/constants';

export default function JurisdictionNotice({ className = '' }) {
  return (
    <div
      className={`rounded-xl bg-slate-50 dark:bg-navy-900/50 p-4 border border-slate-200 dark:border-navy-700 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed ${className}`}
    >
      <div className="flex items-start gap-3">
        <Scale className="w-5 h-5 text-brand-blue dark:text-cyan-400 shrink-0 mt-0.5" />
        <div>
          <h5 className="font-semibold text-slate-900 dark:text-slate-100 mb-1">
            General Safety & Jurisdictional Notice
          </h5>
          <p>{JURISDICTION_DISCLAIMER}</p>
        </div>
      </div>
    </div>
  );
}
