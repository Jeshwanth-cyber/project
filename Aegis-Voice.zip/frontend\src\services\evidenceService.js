import apiClient from './api';

export const evidenceService = {
  async getEvidenceList() {
    const res = await apiClient.get('/api/evidence');
    if (Array.isArray(res?.data)) return res.data;
    return res?.data?.items || res?.data?.results || res?.data?.evidence || [];
  },

  async createEvidence(data) {
    const res = await apiClient.post('/api/evidence', data);
    return res?.data || {};
  },

  async deleteEvidence(evidenceId) {
    try {
      const res = await apiClient.delete(`/api/evidence/${evidenceId}`);
      return res?.data || {};
    } catch (err) {
      if (err.is404) {
        // Fallback to DELETE /api/evidence with query param or body
        const res = await apiClient.delete('/api/evidence', { data: { id: evidenceId } });
        return res?.data || {};
      }
      throw err;
    }
  },
};

export default evidenceService;
