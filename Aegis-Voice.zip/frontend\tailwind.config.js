/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        navy: {
          950: '#060D18',
          900: '#0A1628',
          850: '#0E1D35',
          800: '#0F172A',
          700: '#1E293B',
          600: '#334155',
        },
        brand: {
          blue: '#2563EB',
          'blue-hover': '#1D4ED8',
          'blue-light': '#EFF6FF',
          cyan: '#06B6D4',
          'cyan-hover': '#0891B2',
          'cyan-light': '#ECFEFF',
        },
        safe: {
          DEFAULT: '#10B981',
          light: '#ECFDF5',
          dark: '#059669',
          border: '#A7F3D0',
        },
        warning: {
          DEFAULT: '#F59E0B',
          light: '#FFFBEB',
          dark: '#D97706',
          border: '#FDE68A',
        },
        danger: {
          DEFAULT: '#EF4444',
          light: '#FEF2F2',
          dark: '#DC2626',
          border: '#FECACA',
        },
        surface: {
          light: '#FFFFFF',
          'light-subtle': '#F8FAFC',
          dark: '#0F172A',
          'dark-subtle': '#1E293B',
        }
      },
      fontFamily: {
        sans: [
          'Inter',
          '-apple-system',
          'BlinkMacSystemFont',
          'Segoe UI',
          'Roboto',
          'Noto Sans Devanagari',
          'Noto Sans Telugu',
          'Noto Sans Tamil',
          'sans-serif',
        ],
      },
    },
  },
  plugins: [],
};
