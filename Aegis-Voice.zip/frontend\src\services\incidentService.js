import apiClient from './api';

export const incidentService = {
  async getIncidents() {
    const res = await apiClient.get('/api/incidents');
    if (Array.isArray(res?.data)) return res.data;
    return res?.data?.items || res?.data?.results || res?.data?.incidents || [];
  },
};

export default incidentService;
