import axios from 'axios';

const baseURL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

export const apiClient = axios.create({
  baseURL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 30000,
});

// Request interceptor to attach bearer token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('aegis_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for unified defensive error handling & 401 clearing
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    // 401 Unauthorized handling
    if (error.response?.status === 401) {
      localStorage.removeItem('aegis_token');
      localStorage.removeItem('aegis_user');
      window.dispatchEvent(new CustomEvent('aegis:auth_expired'));
    }

    // Defensive error message construction
    let friendlyMessage = "Something unexpected happened. Please try again.";
    let isNetworkError = false;
    let is404 = false;

    if (!error.response || error.code === 'ERR_NETWORK' || error.message?.includes('Network Error')) {
      friendlyMessage = "Can't reach Aegis Voice right now. Please verify your connection or check if the backend service is running.";
      isNetworkError = true;
    } else if (error.response.status === 404) {
      friendlyMessage = "This action isn't available yet.";
      is404 = true;
    } else if (error.response.data?.detail) {
      friendlyMessage = typeof error.response.data.detail === 'string'
        ? error.response.data.detail
        : JSON.stringify(error.response.data.detail);
    } else if (error.response.data?.message) {
      friendlyMessage = error.response.data.message;
    } else if (error.response.status >= 500) {
      friendlyMessage = "The Aegis Voice server encountered an issue processing this request.";
    }

    error.friendlyMessage = friendlyMessage;
    error.isNetworkError = isNetworkError;
    error.is404 = is404;

    return Promise.reject(error);
  }
);

export default apiClient;
