import React from 'react';
import { Loader2 } from 'lucide-react';

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  type = 'button',
  disabled = false,
  loading = false,
  icon: Icon,
  className = '',
  onClick,
  title,
  ...props
}) {
  const baseClasses =
    'inline-flex items-center justify-center font-medium rounded-lg transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed select-none active:scale-[0.99]';

  const sizeClasses = {
    sm: 'text-xs px-2.5 py-1.5 gap-1.5',
    md: 'text-sm px-4 py-2 gap-2',
    lg: 'text-base px-5 py-2.5 gap-2.5',
  };

  const variantClasses = {
    primary:
      'bg-brand-blue hover:bg-brand-blue-hover text-white shadow-sm focus:ring-blue-500 border border-transparent dark:focus:ring-offset-navy-900',
    secondary:
      'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-navy-700 dark:hover:bg-navy-600 dark:text-slate-200 border border-slate-200 dark:border-navy-600 focus:ring-slate-400 dark:focus:ring-offset-navy-900',
    danger:
      'bg-danger hover:bg-red-600 text-white shadow-sm focus:ring-red-500 border border-transparent dark:focus:ring-offset-navy-900',
    safe:
      'bg-safe hover:bg-emerald-600 text-white shadow-sm focus:ring-emerald-500 border border-transparent dark:focus:ring-offset-navy-900',
    outline:
      'border border-slate-300 dark:border-navy-600 hover:bg-slate-50 dark:hover:bg-navy-800 text-slate-700 dark:text-slate-200 focus:ring-blue-500 dark:focus:ring-offset-navy-900',
    ghost:
      'hover:bg-slate-100 dark:hover:bg-navy-800 text-slate-600 dark:text-slate-300 focus:ring-slate-400 dark:focus:ring-offset-navy-900',
    cyan:
      'bg-brand-cyan hover:bg-cyan-600 text-white shadow-sm focus:ring-cyan-500 border border-transparent dark:focus:ring-offset-navy-900',
  };

  return (
    <button
      type={type}
      disabled={disabled || loading}
      onClick={onClick}
      title={title || (disabled ? 'Action currently unavailable' : undefined)}
      className={`${baseClasses} ${sizeClasses[size] || sizeClasses.md} ${variantClasses[variant] || variantClasses.primary} ${className}`}
      {...props}
    >
      {loading ? (
        <Loader2 className="w-4 h-4 animate-spin text-current shrink-0" aria-hidden="true" />
      ) : Icon ? (
        <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
      ) : null}
      <span>{children}</span>
    </button>
  );
}
