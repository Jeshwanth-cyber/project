import apiClient from './api';

export const healthService = {
  async getHealth() {
    const res = await apiClient.get('/api/health');
    return res?.data || {};
  },
};

export default healthService;
