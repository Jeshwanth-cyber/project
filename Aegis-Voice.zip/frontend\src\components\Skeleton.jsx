import React from 'react';

export default function Skeleton({ className = '', count = 1 }) {
  if (count > 1) {
    return (
      <div className="space-y-3">
        {Array.from({ length: count }).map((_, idx) => (
          <div
            key={idx}
            className={`animate-pulse bg-slate-200 dark:bg-navy-700 rounded-lg ${className}`}
          />
        ))}
      </div>
    );
  }

  return (
    <div
      className={`animate-pulse bg-slate-200 dark:bg-navy-700 rounded-lg ${className}`}
    />
  );
}
