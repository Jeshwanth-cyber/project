import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, UploadCloud, MessageSquareWarning, Archive, LifeBuoy } from 'lucide-react';

export default function MobileNav() {
  const items = [
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/upload', label: 'Upload', icon: UploadCloud },
    { to: '/analysis/harassment', label: 'Harassment', icon: MessageSquareWarning },
    { to: '/evidence', label: 'Vault', icon: Archive },
    { to: '/support', label: 'SOS', icon: LifeBuoy, isSos: true },
  ];

  return (
    <nav
      aria-label="Mobile Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-navy-900/95 backdrop-blur-md border-t border-slate-200 dark:border-navy-800 px-2 py-1.5 flex items-center justify-around"
    >
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center py-1 px-2.5 rounded-lg text-[10px] font-medium transition-colors ${
                item.isSos
                  ? 'text-red-500 font-semibold'
                  : isActive
                  ? 'text-brand-blue dark:text-cyan-400 font-semibold'
                  : 'text-slate-500 dark:text-slate-400'
              }`
            }
          >
            <Icon className="w-5 h-5 mb-0.5" />
            <span>{item.label}</span>
          </NavLink>
        );
      })}
    </nav>
  );
}
