import apiClient from './api';

export const alertService = {
  async getAlerts() {
    const res = await apiClient.get('/api/alerts');
    if (Array.isArray(res?.data)) return res.data;
    return res?.data?.items || res?.data?.results || res?.data?.alerts || [];
  },

  async updateAlert(alertId, data) {
    // Defensively handle both PATCH /api/alerts (with payload { id, ... }) and PATCH /api/alerts/:id
    try {
      const res = await apiClient.patch(`/api/alerts/${alertId}`, data);
      return res?.data || {};
    } catch (err) {
      if (err.is404) {
        // Fallback to PATCH /api/alerts with ID in body
        const res = await apiClient.patch('/api/alerts', { id: alertId, ...data });
        return res?.data || {};
      }
      throw err;
    }
  },
};

export default alertService;
