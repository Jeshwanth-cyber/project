import apiClient from './api';

export const mediaService = {
  async uploadMedia(formData, onUploadProgress) {
    const res = await apiClient.post('/api/media/', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress,
    });
    return res?.data || {};
  },

  async getMediaList() {
    const res = await apiClient.get('/api/media/');
    // Handle defensively: either an array directly or { items: [] } or { results: [] }
    if (Array.isArray(res?.data)) return res.data;
    return res?.data?.items || res?.data?.results || res?.data?.data || [];
  },

  async getMediaById(id) {
    const res = await apiClient.get(`/api/media/${id}`);
    return res?.data || null;
  },
};

export default mediaService;
