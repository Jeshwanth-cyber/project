import React from 'react';
import { WifiOff, AlertTriangle, RefreshCw, HelpCircle } from 'lucide-react';
import Button from './Button';

export default function ErrorState({
  error,
  title,
  message,
  onRetry,
  className = '',
}) {
  const isNetwork = error?.isNetworkError || error?.message?.includes('Network Error');
  const is404 = error?.is404 || error?.response?.status === 404;

  const displayTitle =
    title ||
    (isNetwork
      ? "Can't reach Aegis Voice right now"
      : is404
      ? "This action isn't available yet"
      : 'Unable to load content');

  const displayMessage =
    message ||
    error?.friendlyMessage ||
    (isNetwork
      ? "We cannot connect to the Aegis Voice backend service at VITE_API_BASE_URL. Please ensure your backend server is running and accessible."
      : is404
      ? "The requested endpoint or analysis feature has not been enabled on this server instance."
      : error?.message || 'An unexpected error occurred while communicating with the service.');

  const IconComponent = isNetwork ? WifiOff : is404 ? HelpCircle : AlertTriangle;

  return (
    <div
      role="alert"
      className={`flex flex-col items-center justify-center p-8 sm:p-10 text-center rounded-xl bg-red-50/40 dark:bg-red-950/20 border border-red-200/80 dark:border-red-900/40 ${className}`}
    >
      <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-900/40 flex items-center justify-center text-red-600 dark:text-red-400 mb-3">
        <IconComponent className="w-6 h-6" />
      </div>
      <h4 className="text-base font-semibold text-slate-900 dark:text-slate-100 mb-1">
        {displayTitle}
      </h4>
      <p className="text-sm text-slate-600 dark:text-slate-400 max-w-lg mb-5 leading-relaxed">
        {displayMessage}
      </p>
      {onRetry && (
        <Button variant="outline" size="sm" icon={RefreshCw} onClick={onRetry}>
          Try Again
        </Button>
      )}
    </div>
  );
}
