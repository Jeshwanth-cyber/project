import React, { useState } from 'react';
import { HelpCircle, AlertCircle, CheckCircle2 } from 'lucide-react';
import Modal from './Modal';
import Button from './Button';
import toast from 'react-hot-toast';

export default function ModelEstimateNotice({
  score,
  label = 'AI Model Estimate',
  context = 'media manipulation',
}) {
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [reason, setReason] = useState('false_positive');
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmitFeedback = (e) => {
    e.preventDefault();
    setSubmitted(true);
    toast.success('Thank you. Your feedback helps calibrate detection accuracy.', {
      duration: 4000,
    });
    setTimeout(() => {
      setFeedbackOpen(false);
      setSubmitted(false);
      setComment('');
    }, 1200);
  };

  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-slate-50 dark:bg-navy-900/60 rounded-lg border border-slate-200/80 dark:border-navy-700/80 text-xs">
        <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
          <HelpCircle className="w-4 h-4 text-brand-cyan shrink-0" />
          <span>
            <strong className="font-semibold text-slate-800 dark:text-slate-200">{label}:</strong>{' '}
            {score !== undefined && score !== null ? `${score}% confidence estimate` : 'Algorithmic heuristic'}
            {' · '}
            <span className="text-slate-500 dark:text-slate-400">
              Not legal or forensic proof.
            </span>
          </span>
        </div>

        <button
          type="button"
          onClick={() => setFeedbackOpen(true)}
          className="text-brand-blue hover:text-brand-blue-hover dark:text-cyan-400 dark:hover:text-cyan-300 font-medium underline underline-offset-2 transition-colors"
        >
          This looks wrong?
        </button>
      </div>

      <Modal
        isOpen={feedbackOpen}
        onClose={() => setFeedbackOpen(false)}
        title="Model Accuracy Feedback"
        subtitle={`Report a false-positive or discrepancy in this ${context} evaluation.`}
      >
        {submitted ? (
          <div className="text-center py-6">
            <CheckCircle2 className="w-12 h-12 text-safe mx-auto mb-3" />
            <h4 className="text-base font-semibold text-slate-900 dark:text-slate-100">
              Feedback Recorded
            </h4>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              Thank you for improving safety precision for everyone.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmitFeedback} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                What seems inaccurate?
              </label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full rounded-lg border border-slate-300 dark:border-navy-600 bg-white dark:bg-navy-900 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-blue"
              >
                <option value="false_positive">False positive: Content is authentic / harmless</option>
                <option value="false_negative">False negative: Content is harmful / altered</option>
                <option value="wrong_language">Incorrect language or script identification</option>
                <option value="wrong_category">Misclassified harassment type</option>
                <option value="other">Other observation</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                Additional Context (Optional)
              </label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                rows={3}
                placeholder="Explain the real context, regional nuances, or why this score differs from reality..."
                className="w-full rounded-lg border border-slate-300 dark:border-navy-600 bg-white dark:bg-navy-900 px-3 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-blue"
              />
            </div>

            <div className="bg-amber-50 dark:bg-amber-950/30 p-3 rounded-lg border border-amber-200 dark:border-amber-900/40 text-xs text-amber-800 dark:text-amber-300 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                Your input stays confidential and does not publicly alter existing evidence records.
              </span>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setFeedbackOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" variant="primary" size="sm">
                Submit Feedback
              </Button>
            </div>
          </form>
        )}
      </Modal>
    </>
  );
}
