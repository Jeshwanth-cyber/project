import React from 'react';
import { Link } from 'react-router-dom';
import {
  ShieldCheck,
  EyeOff,
  Languages,
  Archive,
  LifeBuoy,
  FileCheck2,
  Lock,
  ArrowRight,
  AlertCircle,
  Sparkles,
  CheckCircle,
} from 'lucide-react';
import Button from '../components/Button';
import ThemeToggle from '../components/ThemeToggle';
import { PRIVACY_PROMISES, HELPLINES } from '../utils/constants';

export default function Landing() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-navy-950 text-slate-900 dark:text-slate-100 selection:bg-brand-blue selection:text-white transition-colors duration-200">
      {/* Top Navigation */}
      <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 sm:px-8 bg-white/80 dark:bg-navy-900/80 backdrop-blur-md border-b border-slate-200/80 dark:border-navy-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-brand-blue flex items-center justify-center text-white shadow-sm">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <span className="font-bold text-lg text-slate-900 dark:text-white tracking-tight">
            Aegis <span className="text-brand-cyan">Voice</span>
          </span>
        </div>

        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Link
            to="/support"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-red-500/10 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900/50 hover:bg-red-500/20 transition-colors"
          >
            <LifeBuoy className="w-3.5 h-3.5" />
            <span>Emergency SOS</span>
          </Link>
          <Link
            to="/login"
            className="text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-200 hover:text-brand-blue dark:hover:text-cyan-400 px-3 py-1.5 transition-colors"
          >
            Sign In
          </Link>
          <Link to="/register">
            <Button variant="primary" size="sm">
              Get Safe Access
            </Button>
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-16 pb-20 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto text-center overflow-hidden">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-900/60 text-xs font-medium text-brand-blue dark:text-blue-400 mb-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <ShieldCheck className="w-4 h-4 text-brand-cyan" />
          <span>Trauma-Informed Digital Protection for NCII & Harassment</span>
        </div>

        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-slate-900 dark:text-white max-w-4xl mx-auto leading-tight">
          A calm, private sanctuary when your digital trust has been breached.
        </h1>

        <p className="mt-6 text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
          Detect manipulated images, deepfakes, and multilingual harassment across English, Hindi, Telugu, and Tamil. We preserve structured forensic evidence you control, without surveillance or invasive scans.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
          <Link to="/register">
            <Button variant="primary" size="lg" icon={ArrowRight}>
              Protect Your Evidence Now
            </Button>
          </Link>
          <Link to="/support">
            <Button variant="outline" size="lg" icon={LifeBuoy}>
              Immediate SOS & Helplines
            </Button>
          </Link>
        </div>

        {/* Clear Scope Guarantee */}
        <div className="mt-12 p-4 rounded-xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-navy-800 shadow-sm max-w-2xl mx-auto text-xs sm:text-sm text-slate-600 dark:text-slate-400 flex items-center justify-center gap-2">
          <Lock className="w-4 h-4 text-emerald-500 shrink-0" />
          <span>
            <strong>No chat eavesdropping:</strong> Analysis runs strictly on files and text you voluntarily upload. We never access your WhatsApp or Signal.
          </span>
        </div>
      </section>

      {/* The Problem & Our Commitment */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto border-t border-slate-200/80 dark:border-navy-800">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            Designed for what existing reporting tools miss
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-600 dark:text-slate-400 leading-relaxed">
            Existing platforms either ignore regional dialects or demand intrusive access. Aegis Voice stands beside you through every step of forensic recovery.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white dark:bg-navy-900 p-6 rounded-2xl border border-slate-200/80 dark:border-navy-800 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-navy-800 flex items-center justify-center text-brand-blue dark:text-cyan-400 mb-4">
              <EyeOff className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
              Deepfake Detection
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              Examines facial blending, boundary anomalies, and synthetic signatures in photos and videos with calibrated model estimates.
            </p>
          </div>

          <div className="bg-white dark:bg-navy-900 p-6 rounded-2xl border border-slate-200/80 dark:border-navy-800 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-navy-800 flex items-center justify-center text-safe mb-4">
              <Languages className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
              Multilingual Harassment
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              Detects targeted abuse, doxxing, and extortion in English, Hindi, Telugu, Tamil, Hinglish, and Tanglish scripts.
            </p>
          </div>

          <div className="bg-white dark:bg-navy-900 p-6 rounded-2xl border border-slate-200/80 dark:border-navy-800 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-navy-800 flex items-center justify-center text-purple-600 dark:text-purple-400 mb-4">
              <Archive className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
              Verifiable Evidence Record
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              Generates cryptographic SHA-256 integrity packages with timestamps and platform metadata you can download for cybercell filing.
            </p>
          </div>

          <div className="bg-white dark:bg-navy-900 p-6 rounded-2xl border border-slate-200/80 dark:border-navy-800 shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-red-50 dark:bg-navy-800 flex items-center justify-center text-red-600 dark:text-red-400 mb-4">
              <LifeBuoy className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
              Calm Reporting Guidance
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              Jurisdiction-aware roadmaps, official platform takedown links, and 24/7 emergency helplines without invented legal jargon.
            </p>
          </div>
        </div>
      </section>

      {/* How it Works Journey */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto border-t border-slate-200/80 dark:border-navy-800">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            The Safe Recovery Journey
          </h2>
          <p className="mt-2 text-sm sm:text-base text-slate-600 dark:text-slate-400">
            Four disciplined steps from initial discovery to formal resolution.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
          {[
            {
              step: '01',
              title: 'Upload Content',
              desc: 'Submit suspect media or harassment text on your terms in an isolated client workspace.',
            },
            {
              step: '02',
              title: 'Analyze & Assess',
              desc: 'Inspect manipulated artifacts or linguistic threats accompanied by honest model confidence bounds.',
            },
            {
              step: '03',
              title: 'Lock Evidence',
              desc: 'Export structured, tamper-evident cryptographic reports ready for legal submission.',
            },
            {
              step: '04',
              title: 'Takedown & Support',
              desc: 'Connect to verified 24/7 helplines, StopNCII hash matching, and cybercell complaint portals.',
            },
          ].map((item, index) => (
            <div
              key={item.step}
              className="bg-white dark:bg-navy-900 p-6 rounded-2xl border border-slate-200/80 dark:border-navy-800 relative"
            >
              <div className="text-3xl font-bold text-brand-blue/30 dark:text-cyan-500/30 mb-3">
                {item.step}
              </div>
              <h3 className="font-semibold text-slate-900 dark:text-white mb-1.5">
                {item.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Privacy Promises */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <div className="bg-gradient-to-br from-slate-900 to-navy-950 text-white rounded-3xl p-8 sm:p-12 shadow-xl border border-navy-700">
          <div className="max-w-2xl mb-8">
            <span className="text-xs font-semibold text-brand-cyan tracking-wider uppercase">
              Our Core Architecture
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold mt-2">
              Privacy Promises We Enforce by Code
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {PRIVACY_PROMISES.map((promise) => (
              <div key={promise.title} className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-safe shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-sm sm:text-base text-slate-100">
                    {promise.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-400 mt-1 leading-relaxed">
                    {promise.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 pt-6 border-t border-navy-800 flex flex-wrap items-center justify-between gap-4">
            <p className="text-xs text-slate-400">
              Need immediate assistance? You do not need to register to view emergency contacts.
            </p>
            <Link to="/support">
              <Button variant="cyan" size="sm" icon={LifeBuoy}>
                Browse Emergency Helplines
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Emergency Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 bg-white dark:bg-navy-900 border-t border-slate-200/80 dark:border-navy-800 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
          <div>
            <div className="flex items-center justify-center md:justify-start gap-2 text-slate-900 dark:text-white font-bold mb-1">
              <ShieldCheck className="w-4 h-4 text-brand-blue" />
              <span>Aegis Voice Platform</span>
            </div>
            <p className="text-xs text-slate-400">
              Privacy-first digital safety and evidence custody. Guidance is general and not formal legal advice.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-medium">
            <Link to="/support" className="text-red-500 hover:underline">
              Cybercrime Helpline (1930)
            </Link>
            <Link to="/support" className="hover:text-slate-900 dark:hover:text-white">
              Emergency Police (112)
            </Link>
            <Link to="/support" className="hover:text-slate-900 dark:hover:text-white">
              StopNCII.org
            </Link>
            <Link to="/login" className="hover:text-slate-900 dark:hover:text-white">
              Account Login
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
