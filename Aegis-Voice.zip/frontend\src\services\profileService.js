import apiClient from './api';

export const profileService = {
  async getProfile() {
    const res = await apiClient.get('/api/profile');
    return res?.data || null;
  },

  async updateProfile(data) {
    const res = await apiClient.patch('/api/profile', data);
    return res?.data || {};
  },

  async deleteAccount(payload) {
    // Supports deleting account defensively
    const res = await apiClient.delete('/api/profile', { data: payload });
    return res?.data || {};
  },
};

export default profileService;
