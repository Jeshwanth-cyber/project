import apiClient from './api';

export const socialService = {
  async getSocialAccounts() {
    const res = await apiClient.get('/api/social/');
    if (Array.isArray(res?.data)) return res.data;
    return res?.data?.accounts || res?.data?.items || res?.data?.data || [];
  },

  async connectSocial(platform, payload = {}) {
    const res = await apiClient.post('/api/social/', {
      platform,
      action: 'connect',
      ...payload,
    });
    return res?.data || {};
  },

  async disconnectSocial(platform) {
    const res = await apiClient.post('/api/social/', {
      platform,
      action: 'disconnect',
    });
    return res?.data || {};
  },
};

export default socialService;
