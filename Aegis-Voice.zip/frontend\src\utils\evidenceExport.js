import { JURISDICTION_DISCLAIMER } from './constants';

/**
 * Calculates SHA-256 hash using the Web Crypto API
 */
export async function calculateHash(contentString) {
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(contentString);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  } catch {
    return 'SHA256-UNAVAILABLE-CLIENT-OFFLINE';
  }
}

/**
 * Creates and downloads a structured evidence record
 */
export async function exportEvidenceRecord(evidenceItem) {
  const generatedAt = new Date().toISOString();
  const rawPayload = JSON.stringify({
    record_id: evidenceItem.id || `EV-${Date.now()}`,
    title: evidenceItem.title || evidenceItem.name || 'Digital Safety Incident Record',
    category: evidenceItem.category || evidenceItem.type || 'Unspecified Incident',
    platform: evidenceItem.platform || 'Direct Upload',
    source_url: evidenceItem.source_url || evidenceItem.url || null,
    risk_level: evidenceItem.risk_level || evidenceItem.risk || 'Unrated',
    model_estimate: evidenceItem.confidence || evidenceItem.score || null,
    explanation: evidenceItem.explanation || evidenceItem.notes || evidenceItem.description || '',
    timestamps_flagged: evidenceItem.timestamps || null,
    indicators: evidenceItem.indicators || [],
    created_at: evidenceItem.created_at || generatedAt,
    exported_at: generatedAt,
  });

  const integrityHash = await calculateHash(rawPayload);

  const structuredRecord = {
    header: {
      system: 'Aegis Voice Evidence Preservation Engine',
      version: '1.0.0',
      record_id: evidenceItem.id || `EV-${Date.now()}`,
      exported_at_utc: generatedAt,
      integrity_checksum_sha256: integrityHash,
      verification_algorithm: 'SHA-256 (Web Cryptography Standard)',
    },
    incident: {
      title: evidenceItem.title || evidenceItem.name || 'Digital Harassment / Synthetic Media Evidence',
      category: evidenceItem.category || evidenceItem.type || 'Media Manipulation',
      platform: evidenceItem.platform || 'Direct Upload',
      source_url: evidenceItem.source_url || evidenceItem.url || 'N/A',
      reported_timestamp: evidenceItem.created_at || generatedAt,
      risk_assessment: evidenceItem.risk_level || evidenceItem.risk || 'Unrated',
      ai_model_estimate_confidence: evidenceItem.confidence || evidenceItem.score || 'N/A (Heuristic)',
      findings_summary: evidenceItem.explanation || evidenceItem.notes || evidenceItem.description || 'No detailed notes provided.',
      detected_indicators: evidenceItem.indicators || [],
      flagged_timestamps: evidenceItem.timestamps || [],
      evidence_raw_text: evidenceItem.text || evidenceItem.content || null,
    },
    chain_of_custody: {
      preserved_by_user_id: evidenceItem.user_id || 'Authenticated Aegis Voice Account',
      storage_location: 'User Encrypted Evidence Vault',
      third_party_transfers: 'None. Retained exclusively under client control.',
    },
    legal_notice: {
      disclaimer: JURISDICTION_DISCLAIMER,
      evidential_notes: 'This document preserves user-submitted metadata, timestamps, and model estimates for cybercrime filing and legal evaluation.',
    },
  };

  const jsonString = JSON.stringify(structuredRecord, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);

  const safeFilename = `Aegis-Evidence-${(evidenceItem.title || 'Record').replace(/[^a-z0-9]/gi, '_').toLowerCase()}-${Date.now()}.json`;

  const link = document.createElement('a');
  link.href = url;
  link.download = safeFilename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  return { filename: safeFilename, hash: integrityHash };
}
