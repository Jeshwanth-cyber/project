import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { Shield, LifeBuoy, Menu, X, LogOut, User, Activity, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import ThemeToggle from '../components/ThemeToggle';
import healthService from '../services/healthService';

export default function Header({ onToggleSidebar, isSidebarOpen }) {
  const { user, logout, isAuthenticated } = useAuth();
  const [healthStatus, setHealthStatus] = useState('checking'); // 'healthy', 'unreachable', 'checking'
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  useEffect(() => {
    let isMounted = true;
    async function checkHealth() {
      try {
        const res = await healthService.getHealth();
        if (isMounted) {
          const isHealthy = res?.status === 'ok' || res?.status === 'healthy' || res?.healthy === true;
          setHealthStatus(isHealthy ? 'healthy' : 'degraded');
        }
      } catch {
        if (isMounted) setHealthStatus('unreachable');
      }
    }

    checkHealth();
    const interval = setInterval(checkHealth, 60000); // Check once a minute
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 sm:px-6 bg-white/90 dark:bg-navy-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-navy-800 transition-colors">
      <div className="flex items-center gap-3">
        {/* Mobile menu button */}
        <button
          type="button"
          onClick={onToggleSidebar}
          className="md:hidden p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-navy-800 focus:outline-none"
          aria-label={isSidebarOpen ? 'Close sidebar' : 'Open sidebar'}
        >
          {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>

        {/* Brand Link */}
        <NavLink to={isAuthenticated ? '/dashboard' : '/'} className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-brand-blue flex items-center justify-center text-white shadow-sm shadow-blue-500/20">
            <Shield className="w-5 h-5" />
          </div>
          <span className="font-bold text-lg text-slate-900 dark:text-white tracking-tight">
            Aegis <span className="text-brand-cyan">Voice</span>
          </span>
        </NavLink>

        {/* Health status badge */}
        <div
          title={
            healthStatus === 'healthy'
              ? 'Backend API Connected & Operational'
              : healthStatus === 'unreachable'
              ? "Can't reach Aegis Voice API"
              : 'Verifying system status'
          }
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-full border border-slate-200 dark:border-navy-700 bg-slate-50 dark:bg-navy-800/60 ml-2"
        >
          <span
            className={`w-2 h-2 rounded-full ${
              healthStatus === 'healthy'
                ? 'bg-emerald-500 animate-pulse'
                : healthStatus === 'unreachable'
                ? 'bg-red-500'
                : 'bg-amber-500'
            }`}
          />
          <span className="text-slate-600 dark:text-slate-300 text-[11px] font-medium">
            {healthStatus === 'healthy'
              ? 'Online'
              : healthStatus === 'unreachable'
              ? 'Offline'
              : 'Checking'}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        {/* SOS Emergency Helpline Button */}
        <NavLink
          to="/support"
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-semibold rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900/50 transition-colors"
          title="Emergency Helplines & Support"
        >
          <LifeBuoy className="w-4 h-4 text-red-500" />
          <span>SOS / Support</span>
        </NavLink>

        {/* Theme Toggle */}
        <ThemeToggle />

        {/* User Profile / Menu */}
        {isAuthenticated && user && (
          <div className="relative">
            <button
              type="button"
              onClick={() => setUserMenuOpen((prev) => !prev)}
              className="flex items-center gap-2 p-1 rounded-full hover:ring-2 hover:ring-brand-blue/30 transition-all focus:outline-none"
              aria-label="User menu"
            >
              <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-navy-700 text-slate-700 dark:text-slate-200 flex items-center justify-center font-semibold text-xs border border-slate-300 dark:border-navy-600">
                {user.name ? user.name.charAt(0).toUpperCase() : 'U'}
              </div>
            </button>

            {userMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setUserMenuOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-56 rounded-xl bg-white dark:bg-navy-800 border border-slate-200 dark:border-navy-700 shadow-xl py-2 z-50 text-xs sm:text-sm animate-in fade-in zoom-in-95 duration-100">
                  <div className="px-4 py-2 border-b border-slate-100 dark:border-navy-700">
                    <p className="font-semibold text-slate-900 dark:text-slate-100 truncate">
                      {user.name || 'Account'}
                    </p>
                    <p className="text-slate-500 dark:text-slate-400 text-xs truncate">
                      {user.email}
                    </p>
                  </div>

                  <NavLink
                    to="/settings"
                    onClick={() => setUserMenuOpen(false)}
                    className="flex items-center gap-2.5 px-4 py-2.5 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-navy-700"
                  >
                    <User className="w-4 h-4 text-slate-400" />
                    <span>Settings & Privacy</span>
                  </NavLink>

                  <button
                    type="button"
                    onClick={() => {
                      setUserMenuOpen(false);
                      logout();
                    }}
                    className="w-full flex items-center gap-2.5 px-4 py-2.5 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/20 text-left"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </header>
  );
}
