import apiClient from './api';

export const analysisService = {
  async analyzeImage(payload) {
    const res = await apiClient.post('/api/analysis/image', payload);
    return res?.data || {};
  },

  async analyzeVideo(payload) {
    const res = await apiClient.post('/api/analysis/video', payload);
    return res?.data || {};
  },

  async analyzeDeepfake(payload) {
    const res = await apiClient.post('/api/analysis/deepfake', payload);
    return res?.data || {};
  },

  async analyzeHarassment(payload) {
    const res = await apiClient.post('/api/analysis/harassment', payload);
    return res?.data || {};
  },

  async getAnalysisList() {
    const res = await apiClient.get('/api/analysis/');
    if (Array.isArray(res?.data)) return res.data;
    return res?.data?.items || res?.data?.results || res?.data?.data || [];
  },

  async getAiStatus() {
    const res = await apiClient.get('/api/ai/status');
    return res?.data || {};
  },
};

export default analysisService;
