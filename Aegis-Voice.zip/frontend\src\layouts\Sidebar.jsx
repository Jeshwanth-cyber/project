import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  UploadCloud,
  Image,
  Video,
  ScanEye,
  MessageSquareWarning,
  Share2,
  Bell,
  Archive,
  LifeBuoy,
  Settings,
  ExternalLink,
  ShieldCheck,
  DoorOpen,
} from 'lucide-react';

const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/upload', label: 'Media Upload', icon: UploadCloud },
  { to: '/analysis/image', label: 'Image Misuse', icon: Image },
  { to: '/analysis/video', label: 'Video Analysis', icon: Video },
  { to: '/analysis/deepfake', label: 'Deepfake Result', icon: ScanEye },
  { to: '/analysis/harassment', label: 'Harassment Text', icon: MessageSquareWarning },
  { to: '/social', label: 'Social Monitoring', icon: Share2 },
  { to: '/alerts', label: 'Alerts', icon: Bell },
  { to: '/evidence', label: 'Evidence Vault', icon: Archive },
  { to: '/support', label: 'SOS & Support', icon: LifeBuoy },
  { to: '/settings', label: 'Settings', icon: Settings },
];

export default function Sidebar({ isOpen, onClose }) {
  const location = useLocation();

  // Quick exit to a safe neutral search engine for safety
  const handleQuickExit = () => {
    window.location.replace('https://www.google.com');
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-navy-950/60 backdrop-blur-sm md:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-white dark:bg-navy-900 border-r border-slate-200/80 dark:border-navy-800 flex flex-col transition-transform duration-200 ease-in-out md:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Sidebar Brand Header */}
        <div className="flex items-center justify-between h-16 px-6 border-b border-slate-100 dark:border-navy-800">
          <NavLink to="/dashboard" onClick={onClose} className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-brand-blue flex items-center justify-center text-white shadow-sm">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-slate-900 dark:text-white tracking-tight">
                Aegis <span className="text-brand-cyan">Voice</span>
              </span>
              <span className="block text-[10px] font-medium text-slate-500 dark:text-slate-400 leading-none">
                Privacy-First Protection
              </span>
            </div>
          </NavLink>
        </div>

        {/* Navigation Items */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          <div className="px-3 pb-2 text-[11px] font-semibold tracking-wider text-slate-400 dark:text-slate-500 uppercase">
            Platform Services
          </div>

          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.to;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={onClose}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-brand-blue/10 text-brand-blue dark:bg-cyan-950/40 dark:text-cyan-400 font-semibold'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-navy-800/80 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive
                      ? 'text-brand-blue dark:text-cyan-400'
                      : 'text-slate-400 dark:text-slate-500'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </NavLink>
            );
          })}
        </div>

        {/* Safe Exit / Privacy Footer in Sidebar */}
        <div className="p-3 border-t border-slate-100 dark:border-navy-800 bg-slate-50/50 dark:bg-navy-900/50">
          <button
            type="button"
            onClick={handleQuickExit}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-navy-800 border border-slate-200 dark:border-navy-700 transition-colors"
            title="Quickly navigate away to a neutral search engine"
          >
            <DoorOpen className="w-3.5 h-3.5 text-slate-500" />
            <span>Quick Exit (Escapes to Google)</span>
          </button>
        </div>
      </aside>
    </>
  );
}
