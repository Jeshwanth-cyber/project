export const HELPLINES = [
  {
    name: 'National Cyber Crime Helpline (India)',
    number: '1930',
    description: 'Government of India national helpline for immediate reporting of cybercrimes and financial/imagery fraud.',
    available: '24/7 Toll-Free',
    url: 'https://cybercrime.gov.in',
    type: 'Emergency Cyber',
  },
  {
    name: 'National Emergency Response Support (India)',
    number: '112',
    description: 'Unified emergency response service for immediate physical safety threats across India.',
    available: '24/7 Immediate Police / Medical / Fire',
    url: 'https://112.gov.in',
    type: 'Police Emergency',
  },
  {
    name: 'Women Helpline (India)',
    number: '1091',
    description: 'Dedicated support for women facing harassment, stalking, or non-consensual image abuse.',
    available: '24/7 Toll-Free',
    url: 'http://ncw.nic.in',
    type: 'Crisis & Stalking',
  },
  {
    name: 'National Commission for Women (NCW)',
    number: '+91 7827170170',
    description: '24/7 WhatsApp and phone grievance cell for women in distress and online obscenity complaints.',
    available: '24/7 WhatsApp & Calling',
    url: 'http://ncw.nic.in',
    type: 'Women Protection',
  },
  {
    name: 'Tele-MANAS Mental Health Support',
    number: '14416',
    description: 'Free, confidential mental health counselling provided by the Government of India in 20+ regional languages.',
    available: '24/7 Multilingual Support',
    url: 'https://telemanas.mohfw.gov.in',
    type: 'Mental Health Counseling',
  },
  {
    name: 'StopNCII.org (Global)',
    number: 'Web Platform',
    description: 'Create privacy-preserving digital hashes of intimate images directly on your device to stop their spread across participating platforms.',
    available: '24/7 Online Hash Submission',
    url: 'https://stopncii.org',
    type: 'NCII Removal',
  },
  {
    name: 'Take It Down (NCMEC)',
    number: 'Web Platform',
    description: 'Helps remove explicit images/videos of anyone under 18 from major social networks.',
    available: '24/7 Free Global Service',
    url: 'https://takeitdown.ncmec.org',
    type: 'Minors NCII Protection',
  },
];

export const PLATFORM_REPORTING_LINKS = [
  {
    platform: 'Instagram',
    name: 'Instagram Help Center',
    url: 'https://help.instagram.com/contact/383679321740945',
    notes: 'Report non-consensual intimate imagery, impersonation, or harassment directly via in-app report or web form.',
    category: 'Social Media',
  },
  {
    platform: 'Facebook',
    name: 'Facebook Safety Reporting',
    url: 'https://www.facebook.com/help/contact/567360146613371',
    notes: 'Report unauthorized images, bullying, or fake profiles posing as you.',
    category: 'Social Media',
  },
  {
    platform: 'X (formerly Twitter)',
    name: 'X Safety Center',
    url: 'https://help.twitter.com/forms/safety',
    notes: 'Report non-consensual nudity, targeted harassment, or synthetic/manipulated media impersonation.',
    category: 'Social Media',
  },
  {
    platform: 'YouTube',
    name: 'YouTube Privacy & Defamation',
    url: 'https://support.google.com/youtube/answer/2801895',
    notes: 'File a privacy complaint or report deepfake videos depicting you without consent.',
    category: 'Video',
  },
  {
    platform: 'Reddit',
    name: 'Reddit Report Form',
    url: 'https://www.reddit.com/report',
    notes: 'Report involuntary pornography (NCII), doxxing, harassment, or non-consensual media.',
    category: 'Forums',
  },
  {
    platform: 'National Cyber Crime Portal',
    name: 'CyberCrime.gov.in (India)',
    url: 'https://cybercrime.gov.in',
    notes: 'File a formal complaint for child abuse material or non-consensual explicit content under Section 66E / 67 / 67A IT Act.',
    category: 'Government Law Enforcement',
  },
];

export const EVIDENCE_PRESERVATION_STEPS = [
  {
    step: 1,
    title: 'Do not delete the original messages or posts yet',
    detail: 'Before reporting or blocking, take uncropped screenshots showing the sender’s full handle/phone number, date, time, and visible URL.',
  },
  {
    step: 2,
    title: 'Capture full profile URLs and unique IDs',
    detail: 'Handles can be renamed quickly. Copy the direct profile URL (e.g., instagram.com/username) and copy the post permalink.',
  },
  {
    step: 3,
    title: 'Preserve full header information & timestamps',
    detail: 'If harassment occurred via email or direct message, capture the raw header or device system clock in your screenshot.',
  },
  {
    step: 4,
    title: 'Secure files in the Aegis Evidence Vault',
    detail: 'Upload screenshots and media to generate cryptographic timestamp records you can present to authorities.',
  },
  {
    step: 5,
    title: 'Block and report using platform tools',
    detail: 'Once evidence is preserved and saved, use platform reporting tools and block the account to minimize continuous exposure.',
  },
];

export const JURISDICTION_DISCLAIMER =
  "Aegis Voice provides technical incident assessment, evidence archiving, and general safety guidance. This information is intended to help organize your documentation and does not constitute formal legal counsel or legal representation. Cybercrime laws, evidentiary requirements, and reporting protocols vary by state and nation. We advise verifying with local legal counsel, cyber cell authorities, or registered support organizations.";

export const PRIVACY_PROMISES = [
  {
    title: 'Zero End-to-End Chat Scanning',
    description: 'We never access, monitor, or intercept private WhatsApp, Signal, or encrypted chat sessions. Analysis runs strictly on media and text you intentionally upload.',
  },
  {
    title: 'No Auto-Sharing or Third-Party Disclosures',
    description: 'Your uploaded media, transcripts, and evidence records remain strictly confidential. We never send your personal media to social networks or external agencies without your explicit command.',
  },
  {
    title: 'Client-Controlled Evidence',
    description: 'Evidence records and download files are generated on your command. You maintain full custody and can delete records from your vault at any time.',
  },
  {
    title: 'No Live Location Tracking',
    description: 'Aegis Voice does not monitor or broadcast your GPS location. Emergency links connect you directly to official regional phone numbers and authenticated portals.',
  },
];
